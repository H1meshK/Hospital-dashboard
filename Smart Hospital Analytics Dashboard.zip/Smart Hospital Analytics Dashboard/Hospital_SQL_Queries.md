**Top 3 busiest departments in last 30 days**

SELECT Department, COUNT(\*) AS Total\_Admissions

FROM Hospital\_Data

WHERE Admission\_Date >= DATEADD(day, -30, GETDATE())

GROUP BY Department

ORDER BY Total\_Admissions DESC



**Average wait time by department**

SELECT Department, AVG(Wait\_Time\_Minutes) AS Avg\_Wait

FROM Hospital\_Data

GROUP BY Department



**Patients readmitted within 10 days**

SELECT \*

FROM Hospital\_Data

WHERE Outcome = 'Readmitted' AND Readmitted\_Within\_10\_Days = 'Yes'



**Beds unused for more than 5 days (simulated)**

SELECT Bed\_Assigned, COUNT(\*) AS Usage\_Count

FROM Hospital\_Data

GROUP BY Bed\_Assigned

HAVING COUNT(\*) < 2



