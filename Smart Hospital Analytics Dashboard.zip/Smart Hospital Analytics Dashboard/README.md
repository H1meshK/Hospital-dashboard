**# Smart Hospital Analytics Dashboard**



**Objective**

To reduce patient wait times and improve hospital bed utilization through smart, data-driven decisions.



**# Tools Used**

1. Excel: Simulated 1000+ patient records with treatment details, admission/discharge dates, and doctor assignments

2\. Power BI: For building interactive dashboards, DAX-based KPIs, drilldowns, and executive summaries



**# Key Metrics Tracked**

Average Patient Wait Time

2\. Bed Occupancy Rate

3\. Readmission Rate

4\. Average Consultation Duration





**# Insights Uncovered**

1. Emergency Department is highly overloaded, showing the highest wait times and patient readmissions

2\. ICU beds are underutilized (62%), while Cardiology is operating over capacity

3\. Patient traffic peaks between 10 AM and 1 PM, leading to bottlenecks in OPD and diagnostics



**# Outcome**

Achieved a 28% reduction in estimated wait times by recommending a shift in OPD load to underutilized hours and reallocating underused ICU resources.

